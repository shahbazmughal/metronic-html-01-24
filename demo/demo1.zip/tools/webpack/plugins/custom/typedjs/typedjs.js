// Typed.js is a library that types. Enter in any string, and watch it type at the speed you've set, backspace what it's typed, and begin a new sentence for however many strings you've set.

import Typed from "typed.js";
window.Typed = Typed;
