// Cookiealert -  A simple, good looking cookie alert for Bootstrap: https://github.com/Wruczek/Bootstrap-Cookie-Alert

require('bootstrap-cookie-alert/cookiealert.js');

require('./cookiealert.scss');
