// Leaflet - Leaflet is the leading open-source JavaScript library for mobile-friendly interactive maps: https://leafletjs.com/

window.L = require('leaflet/dist/leaflet.js');
require('esri-leaflet/dist/esri-leaflet.js');
// window.L.esri = require('esri-leaflet-geocoder');

require('./leaflet.scss');
